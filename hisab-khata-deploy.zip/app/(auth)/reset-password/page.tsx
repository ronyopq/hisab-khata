import { ResetForm } from "@/components/auth/AuthForms";
export default function Page() { return <ResetForm />; }
